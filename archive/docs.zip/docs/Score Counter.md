# Score-Counter

Score Counter is a streamlined score counting app which allows you to keep track of the score of any 2-player game. It is meant to be extremely simple to use and quick to access, and there is no configuration whatsoever to get in your way. Enjoy!

Using this app is as simple as 1, 2, 3:

1. Tap anywhere in the score area to increment the score by one.

2. Tap the ⌄ button to decrement the score by one.

3. Tap the 'Reset' button to reset both scores to zero.

Download at <https://apps.apple.com/us/app/game-score-counter/id1396261289>
